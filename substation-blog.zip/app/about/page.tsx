import Image from "next/image"
import { Briefcase, GraduationCap } from "lucide-react"

import { Separator } from "@/components/ui/separator"

export default function AboutPage() {
  const experience = [
    {
      title: "Electrical Supervisor",
      company: "National Transmission & Despatch Company (NTDC)",
      period: "2003 - Present",
      description:
        "Leading substation maintenance and protection teams, ensuring reliability of high-voltage power systems.",
    },
    {
      title: "Senior Technician",
      company: "National Transmission & Despatch Company (NTDC)",
      period: "1998 - 2003",
      description: "Responsible for maintenance and troubleshooting of substation equipment.",
    },
  ]

  const education = [
    {
      degree: "Bachelor of Electrical Engineering",
      institution: "University of Engineering and Technology",
      year: "1998",
    },
    {
      degree: "Diploma in Power Systems",
      institution: "Technical Training Institute",
      year: "1995",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-50 to-orange-100 py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-orange-700">About Me</h1>
            <p className="text-lg text-gray-700">
              Learn more about my journey in the electrical engineering field and my mission to share knowledge.
            </p>
          </div>
        </div>
      </section>

      {/* Profile Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
            <div className="md:col-span-4 space-y-6">
              <div className="relative h-80 w-full rounded-lg overflow-hidden shadow-lg">
                <Image
                  src="/placeholder.svg?height=400&width=300"
                  alt="Fazli Wahid, Electrical Supervisor"
                  fill
                  className="object-cover"
                />
              </div>

              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-orange-600 mb-4">Contact Information</h3>
                <ul className="space-y-3">
                  <li className="flex items-center gap-2">
                    <span className="font-medium">Email:</span>
                    <a href="mailto:substationfaults@gmail.com" className="text-orange-600 hover:underline">
                      substationfaults@gmail.com
                    </a>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="font-medium">Location:</span>
                    <span>Pakistan</span>
                  </li>
                </ul>
              </div>

              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <h3 className="text-xl font-bold text-orange-600 mb-4">Expertise</h3>
                <ul className="space-y-2">
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-orange-600 rounded-full"></span>
                    <span>Substation Maintenance</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-orange-600 rounded-full"></span>
                    <span>Protection Systems</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-orange-600 rounded-full"></span>
                    <span>Transformer Troubleshooting</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-orange-600 rounded-full"></span>
                    <span>Circuit Breaker Maintenance</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="w-2 h-2 bg-orange-600 rounded-full"></span>
                    <span>Isolator Repair</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="md:col-span-8 space-y-10">
              <div>
                <h2 className="text-3xl font-bold text-orange-600 mb-2">My Story</h2>
                <Separator className="w-24 h-1 bg-orange-600 mb-6" />
                <div className="space-y-4 text-gray-700">
                  <p>
                    Welcome to my blogging platform dedicated to the world of electrical substations and grid stations!
                    I'm Fazli Wahid, an Electrical Supervisor with over 20 years of hands-on experience in Substation
                    Maintenance & Protection at the National Transmission & Despatch Company (NTDC) in Pakistan.
                  </p>
                  <p>
                    My journey in the electrical engineering field has been driven by a passion for ensuring the
                    reliability and efficiency of high-voltage power systems. Throughout my career, I've encountered
                    numerous challenges and developed practical solutions for a wide range of substation equipment
                    issues.
                  </p>
                  <p>
                    What started as personal documentation of troubleshooting techniques has evolved into this
                    comprehensive resource aimed at helping fellow engineers, technicians, and students navigate the
                    complex world of electrical substations.
                  </p>
                  <p>
                    I believe in sharing knowledge and practical insights that can help others in the field avoid common
                    pitfalls and implement best practices for maintaining critical power infrastructure.
                  </p>
                </div>
              </div>

              <div>
                <h2 className="text-3xl font-bold text-orange-600 mb-2">Professional Experience</h2>
                <Separator className="w-24 h-1 bg-orange-600 mb-6" />
                <div className="space-y-6">
                  {experience.map((item, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="mt-1 flex-shrink-0">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-orange-100">
                          <Briefcase className="h-5 w-5 text-orange-600" />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold">{item.title}</h3>
                        <p className="text-orange-600">{item.company}</p>
                        <p className="text-sm text-gray-500">{item.period}</p>
                        <p className="mt-2 text-gray-700">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-3xl font-bold text-orange-600 mb-2">Education</h2>
                <Separator className="w-24 h-1 bg-orange-600 mb-6" />
                <div className="space-y-6">
                  {education.map((item, index) => (
                    <div key={index} className="flex gap-4">
                      <div className="mt-1 flex-shrink-0">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-orange-100">
                          <GraduationCap className="h-5 w-5 text-orange-600" />
                        </div>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold">{item.degree}</h3>
                        <p className="text-orange-600">{item.institution}</p>
                        <p className="text-sm text-gray-500">{item.year}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-3xl font-bold text-orange-600 mb-2">Mission & Vision</h2>
                <Separator className="w-24 h-1 bg-orange-600 mb-6" />
                <div className="space-y-4 text-gray-700">
                  <p>
                    My mission is to illuminate the complex world of electrical substation faults, providing critical
                    insights that enhance power system reliability, safety, and performance. Through this website, I aim
                    to share my extensive knowledge and practical insights into substation maintenance, protection, and
                    fault analysis.
                  </p>
                  <p>
                    I envision a community of electrical professionals who can access practical, experience-based
                    knowledge to improve the reliability and safety of power systems worldwide. By sharing real-world
                    solutions and preventive measures, I hope to contribute to the development of more resilient
                    electrical infrastructure.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

