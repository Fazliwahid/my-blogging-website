import Image from "next/image"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function BlogPage() {
  // Sample blog posts - you would fetch these from your CMS or database
  const blogPosts = [
    {
      id: 1,
      title: "Common Transformer Faults and Their Solutions",
      excerpt: "Learn about the most frequent transformer issues and how to troubleshoot them effectively.",
      date: "March 15, 2025",
      category: "Transformers",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 2,
      title: "Circuit Breaker Maintenance Guide",
      excerpt: "A comprehensive guide to maintaining circuit breakers for optimal performance and longevity.",
      date: "March 10, 2025",
      category: "Circuit Breakers",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 3,
      title: "Isolator Troubleshooting Techniques",
      excerpt: "Expert techniques for diagnosing and fixing common isolator problems in substations.",
      date: "March 5, 2025",
      category: "Isolators",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 4,
      title: "Protection Relay Testing Procedures",
      excerpt: "Step-by-step guide to testing and calibrating protection relays in electrical substations.",
      date: "February 28, 2025",
      category: "Protection",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 5,
      title: "Substation Grounding Systems Explained",
      excerpt: "Understanding the importance of proper grounding in electrical substations for safety and performance.",
      date: "February 20, 2025",
      category: "Safety",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 6,
      title: "Preventive Maintenance Schedules for Substation Equipment",
      excerpt: "Recommended maintenance schedules to keep your substation equipment in optimal condition.",
      date: "February 15, 2025",
      category: "Maintenance",
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  const categories = ["All", "Transformers", "Circuit Breakers", "Isolators", "Protection", "Maintenance", "Safety"]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-orange-50 to-orange-100 py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-orange-700">Blog & Articles</h1>
            <p className="text-lg text-gray-700">
              Explore our collection of expert articles on electrical substation maintenance, troubleshooting, and best
              practices.
            </p>
          </div>
        </div>
      </section>

      {/* Blog Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          {/* Categories */}
          <div className="mb-10 overflow-x-auto">
            <div className="flex space-x-2 min-w-max pb-2">
              {categories.map((category) => (
                <Button
                  key={category}
                  variant={category === "All" ? "default" : "outline"}
                  className={
                    category === "All"
                      ? "bg-orange-600 hover:bg-orange-700"
                      : "border-orange-200 hover:border-orange-300 hover:bg-orange-50"
                  }
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>

          {/* Blog Posts Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post) => (
              <Card key={post.id} className="h-full flex flex-col hover:shadow-lg transition-shadow">
                <div className="relative h-48 w-full">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardHeader>
                  <div className="text-sm text-orange-600 font-medium mb-1">{post.category}</div>
                  <CardTitle className="text-xl">{post.title}</CardTitle>
                  <CardDescription>{post.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-gray-600">{post.excerpt}</p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="text-orange-600 hover:text-orange-700 hover:bg-orange-50 p-0">
                    Read more <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>

          {/* Pagination */}
          <div className="flex justify-center mt-12">
            <div className="flex space-x-2">
              <Button variant="outline" disabled>
                Previous
              </Button>
              <Button className="bg-orange-600 hover:bg-orange-700">1</Button>
              <Button variant="outline">2</Button>
              <Button variant="outline">3</Button>
              <Button variant="outline">Next</Button>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl font-bold">Never Miss an Article</h2>
            <p className="text-orange-100">
              Subscribe to our newsletter to receive the latest articles and updates directly in your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <input
                type="email"
                placeholder="Your email address"
                className="px-4 py-3 rounded-lg text-gray-900 w-full sm:w-auto sm:min-w-[300px]"
              />
              <Button size="lg" className="bg-white text-orange-600 hover:bg-orange-100">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

