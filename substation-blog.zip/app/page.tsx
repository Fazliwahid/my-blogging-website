import Image from "next/image"
import Link from "next/link"
import { Mail, Linkedin, Facebook, Github, ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function Home() {
  // Sample blog posts - you would fetch these from your CMS or database
  const featuredPosts = [
    {
      id: 1,
      title: "Common Transformer Faults and Their Solutions",
      excerpt: "Learn about the most frequent transformer issues and how to troubleshoot them effectively.",
      date: "March 15, 2025",
      category: "Transformers",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 2,
      title: "Circuit Breaker Maintenance Guide",
      excerpt: "A comprehensive guide to maintaining circuit breakers for optimal performance and longevity.",
      date: "March 10, 2025",
      category: "Circuit Breakers",
      image: "/placeholder.svg?height=200&width=400",
    },
    {
      id: 3,
      title: "Isolator Troubleshooting Techniques",
      excerpt: "Expert techniques for diagnosing and fixing common isolator problems in substations.",
      date: "March 5, 2025",
      category: "Isolators",
      image: "/placeholder.svg?height=200&width=400",
    },
  ]

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-orange-50 to-orange-100 py-16 md:py-24">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight text-orange-700">
                Electrical Substation Faults
              </h1>
              <p className="text-lg text-gray-700 max-w-md">
                Expert tips and solutions for transformers, circuit breakers, isolators, and auxiliary systems based on
                real-world experience.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="bg-orange-600 hover:bg-orange-700">
                  Read Latest Articles
                </Button>
                <Button size="lg" variant="outline" className="border-orange-600 text-orange-600 hover:bg-orange-50">
                  Contact Me
                </Button>
              </div>
            </div>
            <div className="relative h-64 md:h-80 rounded-lg overflow-hidden shadow-xl">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Electrical Substation"
                fill
                className="object-cover"
                priority
              />
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-white" id="about">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            <div className="md:col-span-4 relative h-80 rounded-lg overflow-hidden shadow-lg">
              <Image
                src="/placeholder.svg?height=400&width=300"
                alt="Fazli Wahid, Electrical Supervisor"
                fill
                className="object-cover"
              />
            </div>
            <div className="md:col-span-8 space-y-6">
              <div>
                <h2 className="text-3xl font-bold text-orange-600 mb-2">About Me</h2>
                <Separator className="w-24 h-1 bg-orange-600 mb-6" />
              </div>
              <p className="text-gray-700">
                Welcome to my blogging platform dedicated to the world of electrical substations and grid stations! I'm
                Fazli Wahid, an Electrical Supervisor with over 20 years of hands-on experience in Substation
                Maintenance & Protection at the National Transmission & Despatch Company (NTDC) in Pakistan.
              </p>
              <p className="text-gray-700">
                My journey in the electrical engineering field has been driven by a passion for ensuring the reliability
                and efficiency of high-voltage power systems.
              </p>
              <div className="flex space-x-4 pt-4">
                <Link href="https://linkedin.com" className="text-gray-600 hover:text-orange-600">
                  <Linkedin className="h-6 w-6" />
                </Link>
                <Link href="https://facebook.com" className="text-gray-600 hover:text-orange-600">
                  <Facebook className="h-6 w-6" />
                </Link>
                <Link href="mailto:substationfaults@gmail.com" className="text-gray-600 hover:text-orange-600">
                  <Mail className="h-6 w-6" />
                </Link>
                <Link href="https://github.com" className="text-gray-600 hover:text-orange-600">
                  <Github className="h-6 w-6" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl font-bold text-orange-600">Our Mission</h2>
            <Separator className="w-24 h-1 bg-orange-600 mx-auto mb-6" />
            <p className="text-lg text-gray-700">
              We are dedicated to illuminating the complex world of electrical substation faults, providing critical
              insights that enhance power system reliability, safety, and performance. Through this website, I aim to
              share my extensive knowledge and practical insights into substation maintenance, protection, and fault
              analysis.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Blog Posts */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex justify-between items-center mb-10">
            <div>
              <h2 className="text-3xl font-bold text-orange-600">Latest Articles</h2>
              <Separator className="w-24 h-1 bg-orange-600 mt-2" />
            </div>
            <Link href="/blog" className="text-orange-600 hover:text-orange-700 flex items-center gap-2 font-medium">
              View all articles <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredPosts.map((post) => (
              <Card key={post.id} className="h-full flex flex-col hover:shadow-lg transition-shadow">
                <div className="relative h-48 w-full">
                  <Image
                    src={post.image || "/placeholder.svg"}
                    alt={post.title}
                    fill
                    className="object-cover rounded-t-lg"
                  />
                </div>
                <CardHeader>
                  <div className="text-sm text-orange-600 font-medium mb-1">{post.category}</div>
                  <CardTitle className="text-xl">{post.title}</CardTitle>
                  <CardDescription>{post.date}</CardDescription>
                </CardHeader>
                <CardContent className="flex-grow">
                  <p className="text-gray-600">{post.excerpt}</p>
                </CardContent>
                <CardFooter>
                  <Button variant="ghost" className="text-orange-600 hover:text-orange-700 hover:bg-orange-50 p-0">
                    Read more <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-orange-600 text-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="max-w-3xl mx-auto text-center space-y-6">
            <h2 className="text-3xl font-bold">Subscribe to Our Newsletter</h2>
            <p className="text-orange-100">
              Stay updated with the latest articles, tips, and insights on electrical substation maintenance and
              troubleshooting.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
              <input
                type="email"
                placeholder="Your email address"
                className="px-4 py-3 rounded-lg text-gray-900 w-full sm:w-auto sm:min-w-[300px]"
              />
              <Button size="lg" className="bg-white text-orange-600 hover:bg-orange-100">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

