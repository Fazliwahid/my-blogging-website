"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Mail, Menu } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { useMobile } from "@/hooks/use-mobile"

export function SiteHeader() {
  const isMobile = useMobile()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const navItems = [
    { label: "Home", href: "/" },
    { label: "About", href: "/about" },
    { label: "Blog", href: "/blog" },
    { label: "Contact", href: "/contact" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-white">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <div className="relative h-10 w-10">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Substation Faults Logo"
                fill
                className="object-contain"
              />
            </div>
            <span className="hidden font-bold text-orange-600 md:inline-block">Substation Faults</span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-sm font-medium text-gray-700 transition-colors hover:text-orange-600"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <Link
            href="mailto:substationfaults@gmail.com"
            className="hidden md:flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-orange-600"
          >
            <Mail className="h-4 w-4" />
            <span>substationfaults@gmail.com</span>
          </Link>

          <div className="hidden md:block">
            <Button className="bg-orange-600 hover:bg-orange-700">Subscribe</Button>
          </div>

          {/* Mobile Menu */}
          {isMobile && (
            <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                  <span className="sr-only">Toggle menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-[300px] sm:w-[400px]">
                <div className="flex flex-col gap-6 py-6">
                  <Link href="/" className="flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
                    <div className="relative h-10 w-10">
                      <Image
                        src="/placeholder.svg?height=40&width=40"
                        alt="Substation Faults Logo"
                        fill
                        className="object-contain"
                      />
                    </div>
                    <span className="font-bold text-orange-600">Substation Faults</span>
                  </Link>
                  <nav className="flex flex-col gap-4">
                    {navItems.map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        className="text-lg font-medium text-gray-700 transition-colors hover:text-orange-600"
                        onClick={() => setIsMenuOpen(false)}
                      >
                        {item.label}
                      </Link>
                    ))}
                  </nav>
                  <div className="mt-auto">
                    <Link
                      href="mailto:substationfaults@gmail.com"
                      className="flex items-center gap-2 text-sm font-medium text-gray-700 hover:text-orange-600"
                    >
                      <Mail className="h-4 w-4" />
                      <span>substationfaults@gmail.com</span>
                    </Link>
                    <Button className="mt-4 w-full bg-orange-600 hover:bg-orange-700">Subscribe</Button>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          )}
        </div>
      </div>
    </header>
  )
}

