import Link from "next/link"
import { Mail, Linkedin, Facebook, Github } from "lucide-react"

export function SiteFooter() {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white">Substation Faults</h3>
            <p className="text-sm">
              Expert tips and solutions for electrical substation maintenance, protection, and fault analysis.
            </p>
            <div className="flex space-x-4">
              <Link href="https://linkedin.com" className="text-gray-400 hover:text-white">
                <Linkedin className="h-5 w-5" />
              </Link>
              <Link href="https://facebook.com" className="text-gray-400 hover:text-white">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="mailto:substationfaults@gmail.com" className="text-gray-400 hover:text-white">
                <Mail className="h-5 w-5" />
              </Link>
              <Link href="https://github.com" className="text-gray-400 hover:text-white">
                <Github className="h-5 w-5" />
              </Link>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-400 hover:text-white">
                  About
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-gray-400 hover:text-white">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-white">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/category/transformers" className="text-gray-400 hover:text-white">
                  Transformers
                </Link>
              </li>
              <li>
                <Link href="/category/circuit-breakers" className="text-gray-400 hover:text-white">
                  Circuit Breakers
                </Link>
              </li>
              <li>
                <Link href="/category/isolators" className="text-gray-400 hover:text-white">
                  Isolators
                </Link>
              </li>
              <li>
                <Link href="/category/protection" className="text-gray-400 hover:text-white">
                  Protection Systems
                </Link>
              </li>
              <li>
                <Link href="/category/maintenance" className="text-gray-400 hover:text-white">
                  Maintenance
                </Link>
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-white">Contact</h3>
            <p className="text-sm flex items-center gap-2">
              <Mail className="h-4 w-4" />
              <a href="mailto:substationfaults@gmail.com" className="hover:text-white">
                substationfaults@gmail.com
              </a>
            </p>
            <form className="space-y-2">
              <input
                type="email"
                placeholder="Your email address"
                className="w-full px-3 py-2 text-sm rounded bg-gray-800 border border-gray-700 text-white"
              />
              <button
                type="submit"
                className="w-full px-3 py-2 text-sm bg-orange-600 hover:bg-orange-700 text-white rounded"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-6 text-sm text-center text-gray-500">
          <p>© {new Date().getFullYear()} Substation Faults. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

